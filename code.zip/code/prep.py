import pandas as pd, numpy as np, sys
D=sys.argv[1]; OUT=sys.argv[2]
b=pd.read_csv(f'{D}/ball_by_ball.csv'); m=pd.read_csv(f'{D}/matches.csv'); c=pd.read_csv(f'{D}/competitions.csv')
m=m.merge(c,on='comp_id',how='left')
full={'India','Pakistan','Australia','England','New Zealand','South Africa','Sri Lanka','West Indies','Bangladesh','Afghanistan','Ireland','Zimbabwe'}
def tier(r):
    if r.comp_name.startswith('IPL'): return 1
    if r.home_team in full and r.away_team in full: return 2
    return 3
m['tier']=m.apply(tier,axis=1)
# keep clean, completed, non-DLS matches with a winner
ok=m.win_team_id.notna()&m.revised_target.isna()&m.first_inn_revised_overs.isna()&m.second_inn_revised_overs.isna()
print('matches',len(m),'usable',ok.sum()); m=m[ok]
b=b[b.match_id.isin(m.match_id)&b.innings.isin([1,2])].copy()
b['legal']=~b.extras_type.isin(['wide','Overstep','other'])
b['tot']=b.runs+b.extras1_runs+b.extras_2_runs
b['bat_runs']=b.runs
b=b.sort_values(['match_id','innings','innings_ball_num']).reset_index(drop=True)
# state before each delivery
g=b.groupby(['match_id','innings'])
b['runs_before']=g.tot.cumsum()-b.tot
b['wk_before']=g.is_wicket.cumsum()-b.is_wicket.astype(int)
b['legal_before']=g.legal.cumsum()-b.legal.astype(int)
tot=g.tot.sum().unstack().rename(columns={1:'inn1_total',2:'inn2_total'})
mx=g.legal.sum().unstack()
# drop matches with incomplete innings (truncated data)
last=b.groupby(['match_id','innings']).agg(w=('is_wicket','sum'),l=('legal','sum')).unstack()
good=[]
for mid,r in last.iterrows():
    good.append(mid) if (not np.isnan(r[('w',2)]) and not np.isnan(r[('w',1)]) and (r[('l',1)]>=119 or r[('w',1)]>=10)) else None
b=b[b.match_id.isin(good)]
b=b.merge(tot,left_on='match_id',right_index=True)
b['target']=np.where(b.innings==2,b.inn1_total+1,np.nan)
# venue environment (leave-one-match-out, shrunk to tier mean of 1st-inn totals)
mt=m[['match_id','venue_id','tier','match_date','win_team_id','knock_out','comp_id','comp_name','season','match_format','home_team','away_team']].merge(tot[['inn1_total']],left_on='match_id',right_index=True)
tm=mt.groupby('tier').inn1_total.mean()
vs=mt.groupby('venue_id').inn1_total.agg(['sum','count'])
mt=mt.join(vs,on='venue_id'); k=8
mt['venue_par']=((mt['sum']-mt.inn1_total)+k*mt.tier.map(tm))/((mt['count']-1)+k)
b=b.merge(mt[['match_id','venue_par','tier','match_date','win_team_id','knock_out','comp_name','season','match_format']],on='match_id')
b['bat_win']=(b.batting_team_id==b.win_team_id).astype(int)
b['balls_left']=120-b.legal_before
b['needed']=b.target-b.runs_before
b['rrr']=b.needed*6/b.balls_left.clip(lower=1)
b['crr']=b.runs_before*6/b.legal_before.clip(lower=1)
b['is_pace']=(b.pace_or_spin=='Pace').astype(int)
b['ipl']=(b.tier==1).astype(int)
# outcome class
def oc(r_tot,legal,w):
    pass
cls=np.where(~b.legal,8,np.where(b.is_wicket,7,np.select([b.tot==0,b.tot==1,b.tot==2,b.tot==3,b.tot==4],[0,1,2,3,4],5)))
b['oc']=cls
# wicket credit rules
b['dis_striker']=(b.is_wicket)&(b.dismissed_player_id==b.striker_id)
b['bowler_credit']=b.is_wicket&b.dismissal_type.isin(['Caught','Bowled','LBW','Stump','Hit Wicket'])
print(b.shape, b.match_id.nunique(), b.tier.value_counts().to_dict())
print(b.groupby(['match_id','innings']).legal.sum().describe())
b.drop(columns=['delivery_ist_time','stroke','delivery_style','over_or_around','on_or_off','bowl_speed']).to_parquet(OUT) if False else b.drop(columns=['delivery_ist_time','stroke','delivery_style','over_or_around','on_or_off','bowl_speed']).to_pickle(OUT)
