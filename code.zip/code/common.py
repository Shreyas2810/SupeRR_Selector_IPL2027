import pandas as pd, numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier as HGB
from sklearn.model_selection import GroupKFold
from sklearn.metrics import log_loss, brier_score_loss
RUNREP=np.array([0,1,2,3,4,6,0,1])  # representative runs for classes 0..8 -> idx; class7=wicket(0 runs), class8=wide/nb(1 run, not legal)
def feats(inn,legal_before,wk,runs,target,venue_par,ipl,tier):
    bl=120-legal_before
    needed=np.where(inn==2,target-runs,np.nan)
    rrr=np.where(inn==2,needed*6/np.clip(bl,1,None),np.nan)
    pard=np.where(inn==1,runs-venue_par*(120-bl)/120,np.nan)
    return np.c_[inn,bl,wk,runs,np.where(inn==2,target,np.nan),needed,rrr,pard,venue_par,ipl,tier]
def wp_raw(model,inn,lb,wk,runs,target,vp,ipl,tier,terminal_win=None):
    """P(batting team wins) for arbitrary states incl. terminal handling."""
    n=len(inn); out=np.zeros(n)
    inn=np.asarray(inn); lb=np.asarray(lb); wk=np.asarray(wk); runs=np.asarray(runs,float)
    target=np.asarray(target,float)
    end=(lb>=120)|(wk>=10)
    # chase terminal
    ch=(inn==2)
    won=ch&(runs>=target)
    tie=ch&(runs==target-1)&end
    live=~end&~won
    out[won]=1.0
    out[ch&end&~won]=np.where(tie[ch&end&~won],0.5,0.0)
    # innings-1 ended -> 1 - P(chasing team wins from start)
    e1=(inn==1)&end
    if e1.any():
        X=feats(np.full(e1.sum(),2),np.zeros(e1.sum()),np.zeros(e1.sum()),np.zeros(e1.sum()),runs[e1]+1,np.asarray(vp)[e1],np.asarray(ipl)[e1],np.asarray(tier)[e1])
        out[e1]=1-model.predict_proba(X)[:,1]
    l=live&~e1
    if l.any():
        X=feats(inn[l],lb[l],wk[l],runs[l],target[l],np.asarray(vp)[l],np.asarray(ipl)[l],np.asarray(tier)[l])
        out[l]=model.predict_proba(X)[:,1]
    return out
