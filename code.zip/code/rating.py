import pandas as pd, numpy as np
WS=(0.40,0.35,0.25)   # weights: observed pressure value, baseline-adjusted pressure skill, consistency
MINHP=100; ACTIVE_SINCE='2025-06-01'; MININN_BALLS=5
def _eb(x,se):
    m=np.average(x,weights=1/se**2); v=x.var(ddof=1); t2=max(v-(se**2).mean(),1e-10)
    return m+(x-m)*t2/(t2+se**2), m, t2
def rate(A, mw=None, weights=WS, minhp=MINHP, active_since=ACTIVE_SINCE, ranked_only=True, mode='full'):
    A=A.copy()
    if mw is not None:
        A=A.join(mw.rename('mw'),on='match_id'); A['mw']=A.mw.fillna(0); A=A[A.mw>0]
        for c in ['vp','vpr','vpw','vnr','vnw','lp','np_','vn','ln','nn','np_raw','nn_raw']: A[c]=A[c]*A.mw
    g=A.groupby('pid')
    S=g.agg(name=('pname','first'),vp=('vp','sum'),vn=('vn','sum'),vpr=('vpr','sum'),vpw=('vpw','sum'),vnr=('vnr','sum'),vnw=('vnw','sum'),
            lp=('lp','sum'),ln=('ln','sum'),np_=('np_','sum'),hp=('np_raw','sum'),allb=('nn_raw','sum'),last=('date','max'),m=('match_id','nunique'))
    S=S[(S.lp>0)&(S.ln>0)]
    A=A[A.pid.isin(S.index)]
    for c in ['vpr','vpw','vnr','vnw']: S['Q_'+c]=S[c]/(S.lp if c.startswith('vp') else S.ln)
    S['Qp']=S.vp/S.lp; S['Qn']=S.vn/S.ln; S['delta']=S.Qp-S.Qn
    S['wpa100']=S.vp/S.np_*100*100
    J=A.join(S[['lp','ln','Q_vpr','Q_vpw','Q_vnr','Q_vnw']].add_prefix('S_'),on='pid')
    se={}
    # linearised cluster-robust SEs over player-innings
    for c in ['vnr','vnw']:
        r=(J[c]-J['S_Q_'+c]*J.ln)/J.S_ln; se[c]=np.sqrt((r**2).groupby(J.pid).sum())
    for c in ['vpr','vpw']:
        r=(J[c]-J['S_Q_'+c]*J.lp)/J.S_lp; se[c]=np.sqrt((r**2).groupby(J.pid).sum())
    for c,(a,b) in {'dr':('vpr','vnr'),'dw':('vpw','vnw')}.items():
        r=(J[a]-J['S_Q_'+a]*J.lp)/J.S_lp-(J[b]-J['S_Q_'+b]*J.ln)/J.S_ln; se[c]=np.sqrt((r**2).groupby(J.pid).sum())
    for k,v in se.items(): S['se_'+k]=v
    S['Q_dr']=S.Q_vpr-S.Q_vnr; S['Q_dw']=S.Q_vpw-S.Q_vnw
    # consistency: share of pressure innings (>=5 pressure balls) that gained win probability
    q=A[A.np_raw>=MININN_BALLS]; p=(q.vp>0).mean()
    S['pinn']=q.groupby('pid').size().reindex(S.index).fillna(0); S['hits']=(q.vp>0).groupby(q.pid).sum().reindex(S.index).fillna(0)
    S['hit_raw']=S.hits/S.pinn.replace(0,np.nan)
    el=(S.np_>=minhp)&(S['last']>=active_since) if ranked_only else (S.np_>=minhp)
    E=S[el].copy()
    tau={}; mean={}
    for c,sc in [('Q_vnr','vnr'),('Q_vnw','vnw'),('Q_dr','dr'),('Q_dw','dw'),('Q_vpr','vpr'),('Q_vpw','vpw')]:
        E[c+'_s'],mean[c],tau[c]=_eb(E[c],E['se_'+sc])
    E['baseline']=E.Q_vnr_s+E.Q_vnw_s; E['clutch']=E.Q_dr_s+E.Q_dw_s
    E['pskill']=E.baseline+E.clutch
    tauPS=tau['Q_vnr']+tau['Q_vnw']+tau['Q_dr']+tau['Q_dw']
    E['z_ps']=(E.pskill-E.pskill.mean())/np.sqrt(tauPS)
    E['ponly']=E.Q_vpr_s+E.Q_vpw_s
    E['z_po']=(E.ponly-E.ponly.mean())/np.sqrt(tau['Q_vpr']+tau['Q_vpw'])
    ee=E[E.pinn>=1]
    obs=np.average((ee.hit_raw-p)**2,weights=ee.pinn); smp=np.average(p*(1-p)/ee.pinn,weights=ee.pinn)
    t2h=max(obs-smp,1e-4); kk=float(np.clip(p*(1-p)/t2h-1,4,200))
    E['hit']=(E.hits+kk*p)/(E.pinn+kk); E['z_h']=(E.hit-p)/np.sqrt(t2h)
    E['score']=weights[0]*E.z_po+weights[1]*E.z_ps+weights[2]*E.z_h
    E['rank']=E.score.rank(ascending=False,method='first')
    E.attrs['tau']=dict(tau,hit=t2h,k=kk)
    return E.sort_values('rank')
if __name__=='__main__':
    pd.set_option('display.width',250); pd.set_option('display.max_columns',30)
    for nm in ('bat','bowl'):
        E=rate(pd.read_pickle(f'agg_{nm}.pkl'))
        print(nm,len(E),{k:round(float(v),5) for k,v in E.attrs['tau'].items()})
        print(E.head(15)[['name','hp','m','Qp','baseline','clutch','pskill','ponly','hit_raw','hit','z_po','z_ps','z_h','score']].round(3).to_string())
