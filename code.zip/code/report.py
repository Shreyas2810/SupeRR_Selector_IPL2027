import pandas as pd, numpy as np, pickle, warnings; warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from sklearn.metrics import log_loss, brier_score_loss
from reportlab.lib.pagesizes import A4; from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether
o=pickle.load(open('final.pkl','rb')); T=pickle.load(open('temporal.pkl','rb')); prof=pickle.load(open('prof.pkl','rb')); rg=pickle.load(open('rr_gap.pkl','rb'))
b=pd.read_pickle('balls_m.pkl'); b['pi']=b.lev/b.lev.mean(); b['hp']=b.pi>=1.5
INK='#222'; ACC='#1f5fa8'; MUT='#8a8f98'; plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':MUT,'axes.labelcolor':INK,'xtick.color':INK,'ytick.color':INK})
ll=log_loss(b.bat_win,b.wp_before.clip(1e-4,1-1e-4)); br=brier_score_loss(b.bat_win,b.wp_before)
# fig1: PI by over, fig2 calibration
f,ax=plt.subplots(1,2,figsize=(8.4,3.0))
g=b.groupby(['innings','overid']).pi.mean().unstack(0)
ax[0].plot(g.index,g[1],color=MUT,lw=2); ax[0].plot(g.index,g[2],color=ACC,lw=2); ax[0].axhline(1.5,color=INK,ls=':',lw=1)
ax[0].text(20.2,g[1].iloc[-1],'1st innings',color=INK,va='center',fontsize=8); ax[0].text(20.2,g[2].iloc[-1],'Chase',color=INK,va='center',fontsize=8)
ax[0].text(1,1.58,'pressure threshold 1.5x',fontsize=8); ax[0].set_xlabel('Over'); ax[0].set_ylabel('Avg Pressure Index'); ax[0].set_title('Pressure builds in the powerplay and at the death',fontsize=9,loc='left'); ax[0].set_xlim(1,22.5)
q=pd.cut(b.wp_before,np.linspace(0,1,11)); c=b.groupby(q,observed=True).agg(p=('wp_before','mean'),a=('bat_win','mean'))
ax[1].plot([0,1],[0,1],color=MUT,lw=1); ax[1].plot(c.p,c.a,'o-',color=ACC,ms=5,lw=1.5); ax[1].set_xlabel('Predicted win prob.'); ax[1].set_ylabel('Actual win rate'); ax[1].set_title('Win-probability model is well calibrated',fontsize=9,loc='left')
plt.tight_layout(); plt.savefig('out/f1.png',dpi=200); plt.close()
def bars(nm,fn,title):
    B=o[nm]['base'].head(10).iloc[::-1]
    f,ax=plt.subplots(figsize=(8.4,3.4)); y=np.arange(10)
    ax.barh(y,B.score,color=ACC,height=0.6)
    ax.set_yticks(y); ax.set_yticklabels(B.name)
    for i,(s,p,lo,hi) in enumerate(zip(B.score,B.p_top10,B.rank_lo,B.rank_hi)): ax.text(s+0.02,i,f'{s:.2f}   P(top-10)={p:.0%}',va='center',fontsize=8,color=INK)
    ax.set_xlim(0,B.score.max()*1.5); ax.set_xlabel('Composite pressure score (SDs of true skill)'); ax.set_title(title,fontsize=9,loc='left')
    ax.xaxis.grid(True,color='#e5e5e5'); ax.set_axisbelow(True); plt.tight_layout(); plt.savefig(fn,dpi=200); plt.close()
bars('bat','out/f3.png','Top-10 batters under pressure'); bars('bowl','out/f4.png','Top-10 bowlers under pressure')
# league table pressure vs ordinary (batting view, balls faced)
bt=b[b.extras_type!='wide']
lt=bt.groupby('hp').agg(n=('tot','size'),rr=('tot',lambda s:s.mean()*6),wk=('is_wicket',lambda s:s.mean()*100),dot=('tot',lambda s:(s==0).mean()*100),bd=('is_four',lambda s:0),pi=('pi','mean'),wp=('wp_before',lambda s:((s>.3)&(s<.7)).mean()*100))
bd=bt.assign(x=bt.is_four|bt.is_six).groupby('hp').x.mean()*100
S=getSampleStyleSheet(); H1=ParagraphStyle('h1',parent=S['Heading1'],fontSize=15,textColor=colors.HexColor(ACC)); H2=ParagraphStyle('h2',parent=S['Heading2'],fontSize=11.5,textColor=colors.HexColor('#222'))
P=ParagraphStyle('p',parent=S['BodyText'],fontSize=9,leading=12.2); SM=ParagraphStyle('sm',parent=P,fontSize=7.8,leading=10)
def tbl(data,cw=None,fs=7.8):
    t=Table(data,colWidths=cw,repeatRows=1); t.setStyle(TableStyle([('FONTSIZE',(0,0),(-1,-1),fs),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e8eef6')),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('GRID',(0,0),(-1,-1),0.25,colors.HexColor('#c8ccd2')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('TOPPADDING',(0,0),(-1,-1),2),('BOTTOMPADDING',(0,0),(-1,-1),2)])); return t
def toplist(nm):
    B=o[nm]['base'].head(10); AB={'Royal Challengers Bengaluru':'RCB','Chennai Super Kings':'CSK','Mumbai Indians':'MI','Kolkata Knight Riders':'KKR','Sunrisers Hyderabad':'SRH','Punjab Kings':'PBKS','Gujarat Titans':'GT','Delhi Capitals':'DC','Rajasthan Royals':'RR','Lucknow Super Giants':'LSG'}
    r=[['#','Player','IPL 2026','Press. balls','Press. eff.','Baseline','Clutch','Consist.','Score','P(top10)']]
    for i,(pid,x) in enumerate(B.iterrows(),1): r.append([i,x['name'],AB[x.ipl2026] if isinstance(x.ipl2026,str) else 'no 2026 squad',int(x.hp),f'{x.Qp:+.2f}',f'{x.baseline:+.3f}',f'{x.clutch:+.3f}',f'{x.hit_raw:.0%}',f'{x.score:.2f}',f'{x.p_top10:.0%}'])
    return r
cw=[6*mm,36*mm,24*mm,18*mm,17*mm,17*mm,15*mm,16*mm,13*mm,16*mm]
E=[]; A=E.append
A(Paragraph('Most Reliable Players Under Pressure: Rajasthan Royals IPL 2027 Auction',H1))
A(Paragraph('Methodology report | SupeRR Selector Season 2, Round 1 | Data: supplied IPL 2022-26 and T20I 2022-26 ball-by-ball pack (814 usable matches, 194,416 deliveries)',SM)); A(Spacer(1,4))
A(Paragraph('<b>Headline.</b> Pressure is defined from a win-probability model: a delivery is high-pressure when the average swing in win probability it can cause is at least 1.5x the league average. Each player is then judged against what an average player does in the same situation, with heavy statistical shrinkage because pressure samples are small. Rankings below exclude Pakistan nationals (not eligible for the IPL) and players with fewer than 100 (opposition-weighted) pressure balls or no appearance since June 2025.',P)); A(Spacer(1,4))
A(Paragraph('Top-10 batters',H2)); A(tbl(toplist('bat'),cw)); A(Spacer(1,4))
A(Paragraph('Top-10 bowlers',H2)); A(tbl(toplist('bowl'),cw)); A(Spacer(1,3))
A(Paragraph('Pressure eff. = win-probability gained above the situation-expectation per unit of pressure faced (raw, unshrunk). Baseline = shrunk level in ordinary situations. Clutch shift = shrunk pressure-minus-ordinary difference. Consistency = share of pressure innings (5+ pressure balls) that added win probability. Score combines shrunk values in units of estimated true-skill SD. P(top-10) is from 400 match-level bootstrap resamples.',SM))
A(PageBreak())
A(Paragraph('1. Pressure definition',H1))
A(Paragraph('<b>Win-probability model.</b> A gradient-boosted classifier predicts the batting side\'s chance of winning before every delivery, using innings, balls left, wickets lost, runs, target, runs needed, required rate, score versus venue par, competition tier and venue scoring level. It is trained with 5-fold cross-validation grouped by match, so every ball is scored by a model that never saw its match; monotonic constraints and large leaves keep it smooth. Out-of-fold log-loss is %.3f and Brier score %.3f, and calibration is close to the diagonal (Figure 1).'%(ll,br),P)); A(Spacer(1,3))
A(Paragraph('<b>Pressure Index.</b> A second model gives the probability of each delivery outcome (dot, 1, 2, 3, 4, 6, wicket, wide or no-ball) in that state. Leverage is the probability-weighted absolute change in win probability across those outcomes: how much the game can swing on this ball. Pressure Index = leverage divided by the league average, so 1.0 is a typical ball. This single measure folds in required rate, wickets in hand, balls remaining, innings stage and closeness, and it is identical for batting and bowling. A <b>high-pressure ball is one with Pressure Index &#8805; 1.5</b> (19%% of deliveries: 27%% of chase balls, 12%% of first-innings balls).',P)); A(Spacer(1,3))
A(Image('out/f1.png',width=170*mm,height=170*mm*3.0/8.4))
A(Paragraph('Figure 1. Left: average Pressure Index by over. Right: out-of-fold calibration of the win-probability model.',SM)); A(Spacer(1,3))
r=[['','Ordinary balls','High-pressure balls']]
r+= [['Share of deliveries faced','%.0f%%'%(lt.n[False]/lt.n.sum()*100),'%.0f%%'%(lt.n[True]/lt.n.sum()*100)],['Mean Pressure Index','%.2f'%lt.pi[False],'%.2f'%lt.pi[True]],['Runs per over','%.2f'%lt.rr[False],'%.2f'%lt.rr[True]],['Wickets per 100 balls','%.2f'%lt.wk[False],'%.2f'%lt.wk[True]],['Boundary %%','%.1f'%bd[False],'%.1f'%bd[True]],['Balls with win prob. between 30%% and 70%%','%.0f%%'%lt.wp[False],'%.0f%%'%lt.wp[True]]]
r=[[c.replace('%%','%') if isinstance(c,str) else c for c in row] for row in r]
A(tbl(r,[70*mm,40*mm,40*mm],8.2)); A(Paragraph('Table 1. Pressure situations are demonstrably different: closer contests, more boundaries and more wickets (higher variance), with chases dominating.',SM))
A(PageBreak())
A(Paragraph('2. Performance measurement, baselines and rating',H1))
for t in [
 '<b>Per-ball value.</b> For each delivery, value = actual win probability after the ball minus the expected win probability over the outcome distribution for that state. Zero means "what an average player would do here." Batters earn it as striker (wides excluded); bowlers earn the negative. Run-outs not involving the striker, and non-bowler dismissals, are not charged to the bowler or batter respectively. Value is split into a <b>run component</b> and a <b>wicket component</b>, because runs are far more repeatable than dismissals and need different shrinkage.',
 '<b>Pressure efficiency.</b> Sum of value over a player\'s pressure balls divided by the sum of leverage faced. Dividing by leverage means players are not rewarded merely for being handed bigger moments.',
 '<b>Own baseline.</b> The same efficiency on ordinary balls (about 80% of each player\'s sample). Clutch shift = pressure efficiency minus baseline: the "compared with usual performance" test.',
 '<b>Empirical-Bayes shrinkage.</b> Each of six quantities (baseline and clutch shift, run and wicket parts, plus pressure-only) is shrunk toward the pool mean in proportion to its sampling noise, using cluster-robust standard errors over player-innings and a method-of-moments estimate of true between-player variance. Estimated true variance of the wicket and clutch components is close to zero, so they are shrunk almost entirely; the model does not pretend to see skill the data cannot support.',
 '<b>Consistency.</b> Share of a player\'s pressure innings (5+ pressure balls faced or bowled) that gained win probability, beta-binomial shrunk to the pool rate.',
 '<b>Composite.</b> Score = 0.40 x observed shrunk pressure value + 0.35 x baseline-adjusted pressure skill (baseline + clutch shift) + 0.25 x consistency, each expressed in estimated true-skill SDs.',
 '<b>Fair comparison.</b> Eligibility: at least 100 opposition-weighted pressure balls and an appearance since 1 June 2025; Pakistan nationals excluded (IPL ineligible). IPL and T20I are combined because every expectation is conditional on competition tier and venue scoring level. T20Is involving non-Full-Member sides and A-team events carry half weight, which stops players whose whole sample is against weaker opposition from topping the list (a UAE batter led an early version of the model for exactly that reason). Rain-affected, tied-without-result and truncated matches and super overs are excluded.']: A(Paragraph(t,P)); A(Spacer(1,2.5))
A(PageBreak())
A(Paragraph('3. Evidence for the top 10',H1))
A(Image('out/f3.png',width=170*mm,height=170*mm*3.4/8.4)); A(Image('out/f4.png',width=170*mm,height=170*mm*3.4/8.4))
def prow(nm):
    r=[['Player','Powerplay','Middle','Death','Chase share','Role read']]
    for pid,x in o[nm]['base'].head(10).iterrows():
        p=prof[nm].loc[pid]; role=('opener/powerplay' if p.pp>.5 else 'finisher' if p.death>.4 else 'middle-overs') if nm=='bat' else (('death specialist' if p.death>.45 else 'new-ball + death' if p.pp>.35 and p.death>.2 else 'new ball' if p.pp>.35 else 'middle-overs ')+(' (pace)' if p.pace>.5 else ' (spin)'))
        r.append([x['name'],'%.0f%%'%(p.pp*100),'%.0f%%'%(p['mid']*100),'%.0f%%'%(p.death*100),'%.0f%%'%(p.chase*100),role])
    return r
A(Paragraph('Where each player\'s pressure balls come from (share of their pressure balls)',H2))
A(Paragraph('Batters',SM)); A(tbl(prow('bat'),[40*mm,20*mm,20*mm,20*mm,22*mm,40*mm]))
A(Paragraph('Bowlers',SM)); A(tbl(prow('bowl'),[40*mm,20*mm,20*mm,20*mm,22*mm,40*mm]))
A(PageBreak())
A(Paragraph('4. Reliability and limitations',H1))
bt_,bw_=T['bat'],T['bowl']
for t in [
 '<b>The honest headline: pressure-specific skill is hard to measure from about 100-500 pressure balls per player.</b> Split-half reliability of raw pressure efficiency across random match halves is low (Spearman about 0.09 for batters, 0.06 for bowlers), which is why heavy shrinkage and a baseline-anchored component are used. Predicting a player\'s pressure efficiency in the other half, the composite ingredients reach about 0.12 (batters) and 0.08-0.11 (bowlers), roughly on par with naive pressure strike rate or economy (0.12, 0.16), which is not situation-adjusted.',
 '<b>Out-of-time check.</b> Rating players on data before 2026 and testing on 2026: the past top-10 batters (n=%d tested) had 2026 pressure efficiency %+.3f against %+.3f for the rest; for bowlers (n=%d) %+.3f against %+.3f. 90%% intervals on the gap (batters %+.2f to %+.2f, bowlers %+.2f to %+.2f) include zero, so the list should be read as best available evidence, not a guarantee.'%(bt_['n'],bt_['top'],bt_['rest'],bw_['n'],bw_['top'],bw_['rest'],*bt_['gap_ci'],*bw_['gap_ci']),
 '<b>Bootstrap stability.</b> Over 400 match-level resamples, only Vaibhav Sooryavanshi is in the batting top 10 almost always (99%, on a small 114-ball sample, so that figure reflects a large, consistent effect rather than certainty). Most other places are 35-70%. Bowling is similarly spread; Rashid Khan, Josh Hazlewood and Varun Chakravarthy are the most stable.',
 '<b>Sensitivity.</b> Across weights, eligibility cut-offs, minor-team weights and pressure thresholds (1.25x to 2.0x with the ball minimum scaled), 7-10 of the top-10 batters and 8-10 of the top-10 bowlers persist; the core group (Sooryavanshi, Maxwell, Salt, Rickelton, Tim David, Shashank Singh for batting; Rashid Khan, Bumrah, Narine, Hazlewood, Ellis, Pathirana for bowling) is robust.',
 '<b>Limitations.</b> No pre-match team strength, toss or pitch-condition data; opposition quality is handled only by competition tier, not by individual matchup; domestic leagues outside the IPL and T20I are absent, so uncapped talent is invisible; the win-probability model is state-based and cannot capture batting-order or captaincy decisions; some players have few IPL seasons and wide uncertainty; ranks near 10 are statistical ties.']: A(Paragraph(t,P)); A(Spacer(1,3))
sens=pd.concat([pd.Series(o['bat']['overlap']),pd.Series(o['bowl']['overlap'])],axis=1); sens.columns=['Batters (of 10)','Bowlers (of 10)']
A(tbl([['Scenario','Batters in common','Bowlers in common']]+[[k,int(v.iloc[0]),int(v.iloc[1])] for k,v in sens.iterrows()],[80*mm,40*mm,40*mm],8))
A(Paragraph('Note: 2.0x threshold and 150-ball scenarios shrink eligible pools; with the minimum scaled to the smaller pressure sample, overlap is 8 of 10 for both lists.',SM))
A(PageBreak())
A(Paragraph('5. Fit with Rajasthan Royals',H1))
tb,pb,cb=rg['bat']; tw,pw,cw_=rg['bowl']
A(Paragraph('<b>Where RR leaks under pressure (IPL 2024-26, high-pressure balls, efficiency vs league).</b> Batting: ranked %d of 10 overall, strong in the powerplay (%+.3f vs league %+.3f) but flat at the death (%+.3f vs league %+.3f). Bowling: ranked %d of 10, with first-innings pressure bowling the clear weakness (%+.3f, versus %+.3f when defending in chases) and powerplay bowling below league (%+.3f vs %+.3f). The two needs are therefore a death-overs finisher and a first-innings powerplay and death bowler.'%(tb.loc['Rajasthan Royals','rank'],pb.loc['PP','Q'],pb.loc['PP','Q_lg'],pb.loc['Death','Q'],pb.loc['Death','Q_lg'],tw.loc['Rajasthan Royals','rank'],cw_.loc[1,'Q'],cw_.loc[2,'Q'],pw.loc['PP','Q'],pw.loc['PP','Q_lg']),P)); A(Spacer(1,3))
A(Paragraph('<b>Batters that fit.</b> Tim David, Shashank Singh and Rinku Singh take over half their pressure balls at the death, which is RR\'s gap. Glenn Maxwell is the middle-overs-to-death option and, like Reeza Hendricks and Mark Chapman, is not listed in an IPL 2026 squad, so is more likely to reach the pool. Phil Salt and Ryan Rickelton add powerplay pressure value; Klaasen is the middle-overs anchor. Vaibhav Sooryavanshi (ranked 1) and Yashasvi Jaiswal (14) are already at RR, which makes them retention priorities, not auction targets.',P)); A(Spacer(1,3))
A(Paragraph('<b>Bowlers that fit.</b> Matheesha Pathirana (55% of pressure balls at the death), Josh Hazlewood and Nathan Ellis (new ball plus death), and Jasprit Bumrah address the first-innings gap. Rashid Khan, Sunil Narine and Maheesh Theekshana (the latter not in a 2026 squad) give high-quality middle-overs pressure control. Varun Chakravarthy and Axar Patel are cheaper spin depth.',P)); A(Spacer(1,3))
A(Paragraph('<b>Availability caveat.</b> The 2027 auction is reported for 16 December in Goa with retention lists due around 15 November. Retention lists were not confirmed when this was written, and the data pack carries no contract status, so "not in an IPL 2026 squad" is only a hint about who is likely to reach the pool. Players in a 2026 squad may be retained, and any trade or foreign-player rule limits must be checked before bidding.',P)); A(Spacer(1,3))
A(Paragraph('<b>Reproducibility.</b> Pipeline: clean and join files, derive state, cross-fit win-probability and outcome models, compute leverage, aggregate per player-innings, shrink and score, bootstrap. Key parameters: threshold 1.5x, minor-team weight 0.5, minimum 100 weighted pressure balls, active since 2025-06-01, weights 0.40/0.35/0.25, 5-fold match-grouped cross-fitting, 400 bootstrap draws, seed 2026. Code is supplied alongside this report.',P))
SimpleDocTemplate('out/RR_Pressure_Players_Report.pdf',pagesize=A4,leftMargin=15*mm,rightMargin=15*mm,topMargin=14*mm,bottomMargin=14*mm,title='Most Reliable Players Under Pressure').build(E)
for nm,fn in (('bat','batters'),('bowl','bowlers')):
    B=o[nm]['base']; B[['name','nation','ipl2026','hp','m','Qp','wpa100','baseline','clutch','hit_raw','score','rank','p_top10','rank_lo','rank_hi']].round(4).to_csv(f'out/full_ratings_{fn}.csv')
