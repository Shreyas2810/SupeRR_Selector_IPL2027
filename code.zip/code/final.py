import pandas as pd, numpy as np, pickle, warnings; warnings.filterwarnings('ignore')
from rating import rate
from scipy.stats import spearmanr
M=pd.read_pickle('meta.pkl')
pak=set(M.index[M.nation=='Pakistan'])
def load(nm,suf=''):
    A=pd.read_pickle(f'agg_{nm}{suf}.pkl'); return A[~A.pid.isin(pak)]
out={}
rng=np.random.default_rng(2026)
for nm in ('bat','bowl'):
    A=load(nm); base=rate(A); base=base.join(M[['nation','ipl2026','ipl_seasons']])
    top10=list(base.index[:10])
    # bootstrap over matches
    mids=A.match_id.unique(); B=400; ranks=pd.DataFrame(index=base.index,columns=range(B),dtype=float)
    for i in range(B):
        mw=pd.Series(rng.multinomial(len(mids),np.ones(len(mids))/len(mids)),index=mids)
        E=rate(A,mw=mw); ranks.loc[E.index.intersection(base.index),i]=E['rank'].reindex(base.index).dropna()
    base['p_top10']=(ranks<=10).sum(1)/ranks.notna().sum(1)
    base['p_top20']=(ranks<=20).sum(1)/ranks.notna().sum(1)
    base['rank_med']=ranks.median(1); base['rank_lo']=ranks.quantile(.05,axis=1); base['rank_hi']=ranks.quantile(.95,axis=1)
    # sensitivity scenarios
    sc={}
    for name,kw in {'weights 0.6/0.2/0.2':dict(weights=(0.6,0.2,0.2)),'weights 0.25/0.5/0.25':dict(weights=(0.25,0.5,0.25)),'weights 0.5/0.5/0 (no consistency)':dict(weights=(0.5,0.5,0.0)),
                    'min 70 pressure balls':dict(minhp=70),'min 150 pressure balls':dict(minhp=150),'active since 2024-06':dict(active_since='2024-06-01')}.items():
        sc[name]=rate(A,**kw)
    for name,suf in {'pressure threshold 1.25x':'_t125','pressure threshold 2.0x':'_t200','T20I minor-team weight 0':'_t3_0','T20I minor-team weight 1':'_t3_1'}.items():
        sc[name]=rate(load(nm,suf))
    sens=pd.DataFrame({k:[int(v['rank'].get(p,99)) if p in v.index else 99 for p in top10] for k,v in sc.items()},index=base.loc[top10,'name'])
    ov={k:len(set(v.index[:10])&set(top10)) for k,v in sc.items()}
    out[nm]=dict(base=base,sens=sens,overlap=ov,tau=base.attrs.get('tau'))
    print(nm,'overlap of top10 with base under scenarios:',ov)
    print(sens.to_string())
pickle.dump(out,open('final.pkl','wb'))
