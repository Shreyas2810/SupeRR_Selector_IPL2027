import pandas as pd, numpy as np
b=pd.read_pickle('balls_m.pkl')
b['pi']=b.lev/b.lev.mean()
import os
THR=float(os.environ.get('THR','1.5')); T3=float(os.environ.get('T3','0.5')); SUF=os.environ.get('SUF','')
b['hp']=b.pi>=THR
b['w']=np.where(b.tier==3,T3,1.0)
# batter view
bt=b[b.extras_type!='wide'].copy()
bt['val']=np.where(bt.is_wicket&~bt.dis_striker,bt.wpae_nowk,bt.wpae)
bt['I']=bt.dis_striker.astype(float)
bt['pid']=bt.striker_id; bt['pname']=bt.striker_name
bt['sg']=1.0
# bowler view (all deliveries)
bw=b.copy()
bw['val']=-np.where(bw.is_wicket&~bw.bowler_credit,bw.wpae_nowk,bw.wpae)
bw['I']=(bw.is_wicket&bw.bowler_credit).astype(float)
bw['sg']=-1.0
bw['pid']=bw.bowler_id; bw['pname']=bw.bowler_name
def agg(d):
    d=d.assign(vw=d.sg*d.cw*(d.I-d.p7)); d['vr']=d.val-d.vw
    d=d.assign(vpr=d.vr*d.w*d.hp, vpw=d.vw*d.w*d.hp, vnr=d.vr*d.w*~d.hp, vnw=d.vw*d.w*~d.hp,vp=d.val*d.w*d.hp, lp=d.lev*d.w*d.hp, np_=d.w*d.hp, vn=d.val*d.w*~d.hp, ln=d.lev*d.w*~d.hp, nn=d.w*~d.hp,
               np_raw=d.hp.astype(int),nn_raw=(~d.hp).astype(int), ipl_hp=(d.hp&(d.tier==1)).astype(int),
               dot=((d.tot==0)&d.hp).astype(int), runs_hp=d.tot*d.hp, wk_hp=(d.is_wicket&d.hp).astype(int),
               runs_n=d.tot*~d.hp, wk_n=(d.is_wicket&~d.hp).astype(int), sixfour=((d.is_four|d.is_six)&d.hp).astype(int))
    return d.groupby(['pid','match_id','innings']).agg(pname=('pname','first'),date=('match_date','first'),tier=('tier','first'),
        vp=('vp','sum'),vpr=('vpr','sum'),vpw=('vpw','sum'),vnr=('vnr','sum'),vnw=('vnw','sum'),lp=('lp','sum'),np_=('np_','sum'),vn=('vn','sum'),ln=('ln','sum'),nn=('nn','sum'),np_raw=('np_raw','sum'),nn_raw=('nn_raw','sum'),
        dot=('dot','sum'),runs_hp=('runs_hp','sum'),wk_hp=('wk_hp','sum'),runs_n=('runs_n','sum'),wk_n=('wk_n','sum'),sixfour=('sixfour','sum')).reset_index()
A=agg(bt); B=agg(bw)
A.to_pickle(f'agg_bat{SUF}.pkl'); B.to_pickle(f'agg_bowl{SUF}.pkl')
print('hp share',b.hp.mean(), b.groupby('innings').hp.mean().to_dict())
for nm,X in (('bat',A),('bowl',B)):
    g=X.groupby('pid').agg(name=('pname','first'),hp=('np_raw','sum'),allb=('nn_raw','sum'),m=('match_id','nunique'),last=('date','max'))
    g['tot']=g.hp+g.allb
    print(nm,len(g),(g.hp>=60).sum(),(g.hp>=100).sum(),(g.hp>=150).sum()); print(g.sort_values('hp',ascending=False).head(8))
# league-level distinction pressure vs ordinary
print(bt.groupby('hp').agg(rpb=('tot','mean'),wk=('is_wicket','mean'),dot=('tot',lambda s:(s==0).mean()),n=('tot','size'),pi=('pi','mean'),wp=('wp_before','mean')))
