import pandas as pd, numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier as HGB
from sklearn.model_selection import GroupKFold
from sklearn.metrics import log_loss, brier_score_loss
from common import *
b=pd.read_pickle('balls.pkl')
MONO=[0,0,-1,0,0,-1,-1,1,0,0,0]
def mk(**k): return HGB(max_iter=150,learning_rate=0.04,max_leaf_nodes=8,min_samples_leaf=4000,l2_regularization=5.0,random_state=0,monotonic_cst=MONO,**k)
X=feats(b.innings.values,b.legal_before.values,b.wk_before.values,b.runs_before.values,b.target.values,b.venue_par.values,b.ipl.values,b.tier.values)
y=b.bat_win.values
Xo=np.c_[X[:,[0,1,2,3,5,6,7,8,9,10]],b.is_pace.values]
yo=b.oc.values
gk=GroupKFold(n_splits=5)
n=len(b)
p7=np.zeros(n); cw=np.zeros(n); wp_before=np.zeros(n); wp_after=np.zeros(n); wp_nowk=np.zeros(n); exp_wp=np.zeros(n); lev=np.zeros(n)
RA={0:0,1:1,2:2,3:3,4:4,5:6,7:0,8:1}
for f,(tr,te) in enumerate(gk.split(X,y,b.match_id.values)):
    wm=mk().fit(X[tr],y[tr])
    om=HGB(max_iter=150,learning_rate=0.06,max_leaf_nodes=16,min_samples_leaf=1000,l2_regularization=1.0,random_state=0).fit(Xo[tr],yo[tr])
    d=b.iloc[te]
    inn=d.innings.values; lb=d.legal_before.values; wk=d.wk_before.values; rb=d.runs_before.values
    tg=d.target.values; vp=d.venue_par.values; ip=d.ipl.values; ti=d.tier.values
    wp_before[te]=wp_raw(wm,inn,lb,wk,rb,tg,vp,ip,ti)
    # actual next state
    lb2=lb+d.legal.values.astype(int); wk2=wk+d.is_wicket.values.astype(int); rb2=rb+d.tot.values
    wp_after[te]=wp_raw(wm,inn,lb2,wk2,rb2,tg,vp,ip,ti)
    wp_nowk[te]=wp_raw(wm,inn,lb2,wk,rb2,tg,vp,ip,ti)
    # expected over outcome classes
    P=om.predict_proba(Xo[te]); cl=om.classes_
    wps=np.zeros((len(te),len(cl)))
    for j,k in enumerate(cl):
        legal=(k!=8); w=(k==7)
        wps[:,j]=wp_raw(wm,inn,lb+int(legal),wk+int(w),rb+RA[k],tg,vp,ip,ti)
    exp_wp[te]=(P*wps).sum(1)
    cl=list(cl); p7[te]=P[:,cl.index(7)]; cw[te]=wps[:,cl.index(7)]-wps[:,cl.index(0)]
    lev[te]=(P*np.abs(wps-wp_before[te][:,None])).sum(1)
    print('fold',f,'logloss',log_loss(y[te],np.clip(wp_before[te],1e-4,1-1e-4)),'brier',brier_score_loss(y[te],wp_before[te]))
b['p7']=p7; b['cw']=cw; b['wp_before']=wp_before; b['wp_after']=wp_after; b['wp_nowk']=wp_nowk; b['exp_wp']=exp_wp; b['lev']=lev
b['wpae']=b.wp_after-b.exp_wp          # batting-side surplus vs state-expectation
b['wpae_nowk']=b.wp_nowk-b.exp_wp
print(b[['wp_before','wpae','lev']].describe())
# calibration
b['bin']=pd.cut(b.wp_before,np.linspace(0,1,11)); print(b.groupby('bin',observed=True).agg(p=('wp_before','mean'),a=('bat_win','mean'),n=('bat_win','size')))
print('mean wpae',b.wpae.mean(), 'by innings',b.groupby('innings').wpae.mean().to_dict())
b.to_pickle('balls_m.pkl')
